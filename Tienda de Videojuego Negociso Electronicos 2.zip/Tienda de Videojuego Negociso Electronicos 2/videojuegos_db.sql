-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-07-2025 a las 17:41:08
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `videojuegos_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_pedido`
--

CREATE TABLE `detalles_pedido` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio_unitario` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalles_pedido`
--

INSERT INTO `detalles_pedido` (`id`, `pedido_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES
(1, 1, 8, 1, 60.00),
(2, 1, 3, 1, 70.99),
(3, 1, 4, 1, 40.99),
(4, 2, 10, 1, 90.00),
(5, 2, 1, 1, 59.99),
(6, 2, 2, 1, 59.99),
(7, 2, 3, 1, 70.99),
(8, 3, 4, 1, 40.99),
(9, 4, 1, 1, 59.99),
(10, 4, 2, 1, 59.99),
(11, 4, 3, 1, 70.99),
(12, 4, 4, 1, 40.99),
(13, 5, 2, 2, 59.99),
(14, 6, 8, 1, 60.00),
(15, 7, 3, 1, 70.99),
(16, 8, 4, 1, 40.99),
(17, 9, 1, 2, 59.99),
(18, 10, 11, 7, 42.55),
(19, 10, 10, 1, 90.00),
(20, 11, 3, 3, 70.99);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_pedido`
--

CREATE TABLE `detalle_pedido` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_pedido_proveedor`
--

CREATE TABLE `detalle_pedido_proveedor` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_pedido_proveedor`
--

INSERT INTO `detalle_pedido_proveedor` (`id`, `pedido_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES
(1, 1, 3, 1, 0.00),
(2, 1, 2, 2, 0.00),
(3, 2, 4, 2, 0.00),
(4, 2, 9, 1, 0.00),
(5, 3, 2, 3, 0.00),
(6, 4, 3, 3, 0.00),
(7, 4, 4, 1, 0.00),
(8, 5, 2, 5, 0.00),
(9, 5, 9, 1, 0.00),
(10, 5, 10, 1, 0.00),
(11, 6, 2, 2, 0.00),
(12, 6, 3, 3, 0.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `estatus` enum('pendiente','procesando','enviado','entregado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `usuario_id`, `fecha`, `estatus`) VALUES
(1, 1, '2025-07-22 11:37:29', 'pendiente'),
(2, 1, '2025-07-22 12:53:10', 'pendiente'),
(3, 3, '2025-07-22 12:58:28', 'pendiente'),
(4, 4, '2025-07-23 08:14:35', 'pendiente'),
(5, 5, '2025-07-24 07:55:38', 'pendiente'),
(6, 5, '2025-07-24 07:55:55', 'pendiente'),
(7, 5, '2025-07-24 07:56:07', 'pendiente'),
(8, 3, '2025-07-24 08:10:36', 'pendiente'),
(9, 3, '2025-07-24 08:11:03', 'pendiente'),
(10, 3, '2025-07-24 08:15:28', 'pendiente'),
(11, 5, '2025-07-24 09:12:28', 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_proveedor`
--

CREATE TABLE `pedidos_proveedor` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `estatus` enum('pendiente','en espera','entregado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos_proveedor`
--

INSERT INTO `pedidos_proveedor` (`id`, `proveedor_id`, `fecha`, `estatus`) VALUES
(1, 2, '2025-07-23 09:16:52', 'pendiente'),
(2, 4, '2025-07-23 09:19:13', 'pendiente'),
(3, 2, '2025-07-24 07:27:59', 'pendiente'),
(4, 3, '2025-07-24 07:28:42', 'en espera'),
(5, 4, '2025-07-24 07:33:29', 'pendiente'),
(6, 2, '2025-07-24 09:14:02', 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `imagen`, `proveedor_id`) VALUES
(1, 'The legend of Zelda', 'Aventura épica con exploración en mundo abierto', 59.99, 'zelda.jpg', 1),
(2, 'Halo Infinite', 'Una nueva version de la aclamada saga de HALO llevandonos a un nuevo anillo, donde el mapa de esta vez es un mundo abierto lo cual nos da la oportunidad de disfrutar mas de la aventura que nos entrega esta saga', 59.99, 'Halo.jpg', 2),
(3, 'A Quiet Place', '\"A Quiet Place: The Road Ahead\" es un juego de aventura y terror para un jugador, basado en la franquicia cinematográfica \"Un lugar en Silencio\".', 70.99, 'aquietplace.jpg', 3),
(4, 'LEGO HARRY POTTER COLLECTION ', 'Es una aventura de acción y aventura que recrea las historias de Harry Potter utilizando piezas de Lego. Los jugadores pueden explorar los lugares emblemáticos de las películas, como Hogwarts, el Callejón Diagon y Hogsmeade, y participar en hechizos, duelos, clases y resolución de acertijos', 40.99, 'LHPC.jpg', 4),
(8, 'LEGO INCREIBLES', 'Vive las apasionantes aventuras de la familia Parr mientras lidian con criminales y con su vida familiar a través de las dos películas de Disney Pixar, Los Increíbles y Los Increíbles 2, en un mundo LEGO® lleno de diversión y humor.', 60.00, 'Linc.jpg', 4),
(9, 'LEGO STAR WARS SKYWALKER SAGA', 'Juega a través de las nueve películas de la saga Star Wars en un videojuego LEGO completamente nuevo y distinto de cualquier otro.', 85.57, 'Lsw.jpg', 4),
(10, 'Silent Hill 2 REMAKE', 'Silent Hill 2 Remake es una versión renovada del clásico juego de terror psicológico, Silent Hill 2, lanzado originalmente en 2001.', 90.00, 'SilentHill2.jpg', 1),
(11, 'FIFA24', 'EA Sports FC 24, conocido anteriormente como FIFA, es un videojuego de fútbol que ofrece una experiencia auténtica con más de 19,000 jugadores, 700 equipos y 30 ligas con licencia.', 42.55, 'fifa24.jpg', 5),
(12, 'Shadow of Mordor', '\"La Tierra Media: Sombras de Mordor\" es un videojuego de acción y aventura en mundo abierto ambientado en el universo de El Señor de los Anillos, entre los eventos de El Hobbit y El Señor de los Anillos', 10.15, 'SHM.jpg\r\n', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_proveedor`
--

CREATE TABLE `producto_proveedor` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `proveedor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto_proveedor`
--

INSERT INTO `producto_proveedor` (`id`, `producto_id`, `proveedor_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 8, 4),
(6, 9, 4),
(7, 11, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prospectos`
--

CREATE TABLE `prospectos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mensaje` text DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `contacto_email` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `nombre`, `contacto_email`, `telefono`) VALUES
(1, 'NINTENDO', '	contacto@nintendo.com', '	5551234567'),
(2, '343 INDUSTRIES', '343industries@industries.com', '	5556789420'),
(3, 'MERIDEM', 'meridem@meri.com', '	5554856719'),
(4, 'TTGAMES', 'ttgames@hasbro.com', '	5555864237'),
(5, 'EA Sports ', 'easports2000@sports.com', '	5559234675');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `rol` enum('cliente','admin') DEFAULT 'cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `rol`) VALUES
(1, 'Alonso Mortera ', 'Mewingmonster43@gmail.com', 'Alonsoelmejor77', 'cliente'),
(3, 'Jose', 'pepe_mortera@hotmail.com', '$2y$10$dQNvwIRTIr6sp/yg0U/3muvyVx1EwcieLPJNDVTpwXdxecLXxGJSK', 'admin'),
(4, 'Laura', 'lauramorsa@hotmail.com', '$2y$10$a.bs67ruxzKZcOCwKHNtaO1h5Fy0uJD9rooKb6BGZWPivr1JV9cXS', 'cliente'),
(5, 'Emmanuel', 'ortegadelu250212@gmail.com', '$2y$10$Qmb4XZmxchDv722dbE7o9Oez7MuHrtvgWAGKDS1SqLjNEaB7GirJC', 'cliente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `detalle_pedido_proveedor`
--
ALTER TABLE `detalle_pedido_proveedor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `pedidos_proveedor`
--
ALTER TABLE `pedidos_proveedor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proveedor_id` (`proveedor_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proveedor_id` (`proveedor_id`);

--
-- Indices de la tabla `producto_proveedor`
--
ALTER TABLE `producto_proveedor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`),
  ADD KEY `proveedor_id` (`proveedor_id`);

--
-- Indices de la tabla `prospectos`
--
ALTER TABLE `prospectos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detalle_pedido_proveedor`
--
ALTER TABLE `detalle_pedido_proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `pedidos_proveedor`
--
ALTER TABLE `pedidos_proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `producto_proveedor`
--
ALTER TABLE `producto_proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `prospectos`
--
ALTER TABLE `prospectos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  ADD CONSTRAINT `detalles_pedido_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`),
  ADD CONSTRAINT `detalles_pedido_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  ADD CONSTRAINT `detalle_pedido_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalle_pedido_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `detalle_pedido_proveedor`
--
ALTER TABLE `detalle_pedido_proveedor`
  ADD CONSTRAINT `detalle_pedido_proveedor_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos_proveedor` (`id`),
  ADD CONSTRAINT `detalle_pedido_proveedor_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `pedidos_proveedor`
--
ALTER TABLE `pedidos_proveedor`
  ADD CONSTRAINT `pedidos_proveedor_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`);

--
-- Filtros para la tabla `producto_proveedor`
--
ALTER TABLE `producto_proveedor`
  ADD CONSTRAINT `producto_proveedor_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `producto_proveedor_ibfk_2` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
