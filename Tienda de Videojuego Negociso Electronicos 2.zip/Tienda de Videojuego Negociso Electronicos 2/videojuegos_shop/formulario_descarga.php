<?php
include("includes/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $telefono = $_POST['telefono'] ?? '';

    if ($nombre && $correo && $telefono) {
        $sql = "INSERT INTO prospectos (nombre, correo, telefono) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $nombre, $correo, $telefono);
        $stmt->execute();

        // Redirigir a descarga
        header("Location: archivo.zip"); // Cambia a tu archivo real
        exit();
    } else {
        $error = "Por favor llena todos los campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Descargar archivo</title>
</head>
<body>
    <h2>Accede a la descarga</h2>
    <?php if (isset($error)): ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <input type="text" name="nombre" placeholder="Tu nombre" required><br>
        <input type="email" name="correo" placeholder="Correo electrónico" required><br>
        <input type="tel" name="telefono" placeholder="Teléfono" required><br>
        <button type="submit">Descargar archivo</button>
    </form>
</body>
</html>
