<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['correo'])) {
    header("Location: login.php");
    exit();
}

include("includes/db.php");

$email = $_SESSION['correo'];
$sql = "SELECT * FROM usuarios WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if (!$usuario) {
    echo "Usuario no encontrado.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Mi Perfil</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
    <style>
        /* (Aquí va todo tu CSS exactamente igual que lo diste) */
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            color: #333;
        }

        .perfil-container {
            background: #fff;
            border-radius: 15px;
            padding: 30px 40px;
            max-width: 480px;
            width: 100%;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            text-align: center;
        }

        .avatar {
            width: 100px;
            height: 100px;
            background: #2575fc;
            border-radius: 50%;
            margin: 0 auto 25px auto;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 40px;
            font-weight: 700;
            user-select: none;
            box-shadow: 0 4px 10px rgba(37, 117, 252, 0.6);
        }

        h2 {
            font-weight: 600;
            margin-bottom: 25px;
            color: #2575fc;
        }

        .info {
            text-align: left;
            margin-bottom: 30px;
        }

        .info p {
            font-size: 16px;
            margin: 12px 0;
            line-height: 1.4;
        }

        .info strong {
            color: #555;
            width: 80px;
            display: inline-block;
        }

        .btn-group {
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 30px;
            background-color: #2575fc;
            color: white;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
            user-select: none;
            box-shadow: 0 4px 10px rgba(37, 117, 252, 0.4);
        }

        .btn:hover {
            background-color: #1a52c2;
        }

        @media (max-width: 500px) {
            .perfil-container {
                padding: 25px 20px;
            }
            .btn-group {
                flex-direction: column;
            }
            .btn {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<div class="perfil-container">
    <div class="avatar" aria-label="Avatar Usuario">
        <?php echo strtoupper(substr($usuario['nombre'], 0, 1)); ?>
    </div>

    <h2>Mi Perfil</h2>

    <div class="info">
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombre']); ?></p>
        <p><strong>Correo:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
        <p><strong>Rol:</strong> <?php echo htmlspecialchars($usuario['rol']); ?></p>
    </div>

    <div class="btn-group">
        <a href="index.php" class="btn" role="button" aria-label="Volver a la tienda">Volver a la tienda</a>
        <a href="logout.php" class="btn" role="button" aria-label="Cerrar sesión">Cerrar sesión</a>
    </div>
</div>

</body>
</html>
