<?php
include("includes/db.php");
session_start();

// Obtener productos de la base de datos
$sql = "SELECT * FROM productos";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tienda de Videojuegos</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #1c1c2b;
            color: #fff;
        }

        header {
            background-color: #29293d;
            padding: 15px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 26px;
            color: #66c2ff;
        }

        .productos {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            padding: 30px;
        }

        .producto {
            background-color: #2f2f44;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 0 10px #00000066;
            transition: transform 0.2s;
        }

        .producto:hover {
            transform: scale(1.02);
        }

        .producto img {
            width: 100%;
            max-height: 180px;
            object-fit: cover;
            border-radius: 8px;
        }

        .producto h3 {
            margin: 10px 0 5px;
            font-size: 18px;
        }

        .producto p {
            font-size: 14px;
            color: #cccccc;
        }

        .precio {
            margin: 10px 0;
            font-size: 16px;
            font-weight: bold;
            color: #4caf50;
        }

        .btn {
            padding: 8px 15px;
            background-color: #66c2ff;
            border: none;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #4fa6e6;
        }
    </style>
</head>
<body>
    <div style="text-align: right; margin-bottom: 20px;">
    <a href="carrito.php" style="color: #66c2ff; font-weight: bold; text-decoration: none;">🛒 Ver carrito</a>
</div>

    <header>
        <h1>Tienda de Videjuegos</h1>
    </header>

    <div class="productos">
        <?php if ($resultado->num_rows > 0): ?>
            <?php while ($producto = $resultado->fetch_assoc()): ?>
                <div class="producto">
                    <img src="assets/img/<?php echo $producto['imagen']; ?>" alt="<?php echo $producto['nombre']; ?>">
                    <h3><?php echo $producto['nombre']; ?></h3>
                    <p><?php echo substr($producto['descripcion'], 0, 60) . '...'; ?></p>
                    <div class="precio">$<?php echo number_format($producto['precio'], 2); ?></div>
                    <form method="POST" action="carrito.php">
    <input type="hidden" name="producto_id" value="<?php echo $producto['id']; ?>">
    <input type="submit" class="btn" value="Agregar al carrito">
</form>


                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No hay productos disponibles.</p>
        <?php endif; ?>
    </div>
</body>
</html>

