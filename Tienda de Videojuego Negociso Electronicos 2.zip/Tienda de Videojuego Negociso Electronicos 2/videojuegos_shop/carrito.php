<?php
session_start();
include("includes/db.php");

// Agregar producto desde index.php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["producto_id"])) {
    $producto_id = $_POST["producto_id"];

    if (isset($_SESSION["carrito"][$producto_id])) {
        $_SESSION["carrito"][$producto_id]["cantidad"] += 1;
    } else {
        $sql = "SELECT * FROM productos WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows == 1) {
            $producto = $resultado->fetch_assoc();
            $_SESSION["carrito"][$producto_id] = [
                "nombre" => $producto["nombre"],
                "precio" => $producto["precio"],
                "cantidad" => 1
            ];
        }

        $stmt->close();
    }
}

// Modificar cantidad
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["modificar_id"])) {
    $id = $_POST["modificar_id"];
    $nueva = intval($_POST["nueva_cantidad"]);
    if ($nueva > 0) {
        $_SESSION["carrito"][$id]["cantidad"] = $nueva;
    }
}

// Eliminar producto del carrito
if (isset($_GET["eliminar"])) {
    $id = $_GET["eliminar"];
    unset($_SESSION["carrito"][$id]);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Carrito de Compras</title>
    <style>
        body {
            background-color: #1e1e2f;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 90%;
            margin: auto;
            background-color: #2f2f44;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #444;
        }

        th {
            background-color: #39395c;
        }

        input[type="number"] {
            width: 60px;
            padding: 5px;
            border-radius: 5px;
            border: none;
            background-color: #ddd;
            color: #000;
        }

        .total {
            font-weight: bold;
            color: #4caf50;
        }

        .btn {
            padding: 6px 12px;
            background-color: #66c2ff;
            border: none;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
            margin-top: 10px;
        }

        .btn:hover {
            background-color: #4fa6e6;
        }

        .btn-danger {
            background-color: #ff4444;
        }

        .btn-danger:hover {
            background-color: #dd2222;
        }

        .finalizar {
            margin-top: 30px;
            display: flex;
            justify-content: center;
        }

        .success {
            text-align: center;
            margin-bottom: 20px;
            color: #4caf50;
            font-weight: bold;
        }

        /* Botones de perfil y carrito */
        .header-buttons {
            text-align: right;
            margin: 20px 40px;
        }
        .header-buttons a {
            margin-left: 10px;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            font-weight: bold;
        }
        .perfil-btn {
            background-color: #3498db;
        }
        .carrito-btn {
            background-color: #2ecc71;
        }
        .login-btn {
            background-color: #e74c3c;
        }
    </style>
</head>
<body>

    <div class="header-buttons">
        <?php if (isset($_SESSION["usuario_id"])): ?>
            <a href="perfil.php" class="perfil-btn">👤 Mi Perfil</a>
            <a href="carrito.php" class="carrito-btn">🛒 Carrito</a>
        <?php else: ?>
            <a href="login.php" class="login-btn">🔐 Iniciar Sesión</a>
        <?php endif; ?>
    </div>

    <h2>Carrito de Compras</h2>

    <?php if (isset($_GET['exito'])): ?>
        <div class="success">¡Compra finalizada con éxito!</div>
    <?php endif; ?>

    <?php if (!empty($_SESSION["carrito"])): ?>
        <table>
            <tr>
                <th>Producto</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Subtotal</th>
                <th>Acciones</th>
            </tr>

            <?php
            $total = 0;
            foreach ($_SESSION["carrito"] as $producto_id => $item):
                $subtotal = $item["precio"] * $item["cantidad"];
                $total += $subtotal;
            ?>
            <tr>
                <td><?php echo htmlspecialchars($item["nombre"]); ?></td>
                <td>$<?php echo number_format($item["precio"], 2); ?></td>

                <td>
                    <form method="POST" action="carrito.php" style="display: inline-block;">
                        <input type="hidden" name="modificar_id" value="<?php echo $producto_id; ?>">
                        <input type="number" name="nueva_cantidad" value="<?php echo $item["cantidad"]; ?>" min="1">
                        <button type="submit" class="btn" style="font-size: 12px;">Actualizar</button>
                    </form>
                </td>

                <td>$<?php echo number_format($subtotal, 2); ?></td>

                <td>
                    <a class="btn btn-danger" href="carrito.php?eliminar=<?php echo $producto_id; ?>">Eliminar</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3"><strong>Total:</strong></td>
                <td class="total">$<?php echo number_format($total, 2); ?></td>
                <td></td>
            </tr>
        </table>

        <div class="finalizar">
            <form action="finalizar_compra.php" method="POST">
                <button class="btn" style="padding: 10px 20px; font-size: 16px;">Finalizar compra</button>
            </form>
        </div>

    <?php else: ?>
        <p style="text-align:center;">Tu carrito está vacío.</p>
    <?php endif; ?>

</body>
</html>
