<?php
session_start();
include("includes/db.php");

if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit;
}

if (empty($_SESSION["carrito"])) {
    echo "El carrito está vacío.";
    exit;
}

$usuario_id = $_SESSION["usuario_id"];
$carrito = $_SESSION["carrito"];

// Insertar pedido
$sql = "INSERT INTO pedidos (usuario_id) VALUES (?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$pedido_id = $stmt->insert_id;
$stmt->close();

// Insertar detalles del pedido
$sql_detalle = "INSERT INTO detalles_pedido (pedido_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
$stmt_detalle = $conn->prepare($sql_detalle);

foreach ($carrito as $producto_id => $item) {
    $stmt_detalle->bind_param("iiid", $pedido_id, $producto_id, $item["cantidad"], $item["precio"]);
    $stmt_detalle->execute();
}

$stmt_detalle->close();

// Limpiar carrito
unset($_SESSION["carrito"]);

header("Location: carrito.php?exito=1");
exit;
?>
