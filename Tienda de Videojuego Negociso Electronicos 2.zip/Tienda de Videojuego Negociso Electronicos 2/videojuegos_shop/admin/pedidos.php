<?php
session_start();
include("../includes/db.php");

// Validar que sea admin
if (!isset($_SESSION["usuario_rol"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit();
}

// Consulta pedidos con usuario
$sql = "SELECT p.id, p.fecha, p.estatus, u.nombre AS cliente_nombre, u.email AS cliente_email
        FROM pedidos p
        LEFT JOIN usuarios u ON p.usuario_id = u.id
        ORDER BY p.fecha DESC";

$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Gestión de Pedidos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background: #f5f5f5;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        .btn-exportar {
            display: inline-block;
            padding: 10px 20px;
            margin-bottom: 20px;
            background: green;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn-exportar:hover {
            background: darkgreen;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #2575fc;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .estatus-pendiente {
            color: #d9534f;
            font-weight: bold;
        }
        .estatus-completado {
            color: #5cb85c;
            font-weight: bold;
        }
        a {
            color: #2575fc;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .btn-volver {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 20px;
            background: #2575fc;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn-volver:hover {
            background: #1a52c2;
        }
    </style>
</head>
<body>
    <h1>Gestión de Pedidos</h1>

    <!-- Botón para descargar CSV -->
    <a href="exportar_pedidos_csv.php" class="btn-exportar">📥 Descargar CSV</a>

    <table>
        <thead>
            <tr>
                <th>ID Pedido</th>
                <th>Cliente</th>
                <th>Correo</th>
                <th>Fecha</th>
                <th>Estatus</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($resultado && $resultado->num_rows > 0): ?>
                <?php while ($pedido = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $pedido['id']; ?></td>
                        <td><?php echo htmlspecialchars($pedido['cliente_nombre']); ?></td>
                        <td><?php echo htmlspecialchars($pedido['cliente_email']); ?></td>
                        <td><?php echo date("d/m/Y H:i", strtotime($pedido['fecha'])); ?></td>
                        <td class="<?php echo ($pedido['estatus'] === 'pendiente') ? 'estatus-pendiente' : 'estatus-completado'; ?>">
                            <?php echo ucfirst($pedido['estatus']); ?>
                        </td>
                        <td>
                            <a href="ver_pedido.php?id=<?php echo $pedido['id']; ?>">Ver detalle</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No hay pedidos registrados.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn-volver">Volver al Dashboard</a>
</body>
</html>
