<?php
session_start();
include("../includes/db.php");

// Verificar si es admin
if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Cabecera para descarga de CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=pedidos_proveedor.csv');

// Abrir buffer de salida
$output = fopen('php://output', 'w');

// Encabezados del CSV
fputcsv($output, ['ID Pedido', 'Proveedor', 'Producto', 'Cantidad', 'Fecha', 'Estatus']);

// Consultar los pedidos
$sql = "
    SELECT pp.id, pr.nombre AS proveedor, p.nombre AS producto, pp.cantidad, pp.fecha, pp.estatus
    FROM pedidos_proveedor pp
    JOIN proveedores pr ON pp.proveedor_id = pr.id
    JOIN productos p ON pp.producto_id = p.id
";
$resultado = $conn->query($sql);

// Escribir filas
while ($row = $resultado->fetch_assoc()) {
    fputcsv($output, [
        $row['id'],
        $row['proveedor'],
        $row['producto'],
        $row['cantidad'],
        $row['fecha'],
        $row['estatus']
    ]);
}

fclose($output);
exit;
