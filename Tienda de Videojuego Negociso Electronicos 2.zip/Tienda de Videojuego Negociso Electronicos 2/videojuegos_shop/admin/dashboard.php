<?php
include("../includes/db.php");
session_start();

// Verificar si es el admin
if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Panel del Administrador</title>
    <style>
        body {
            background-color: #1e1e2f;
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #2f2f44;
            padding: 20px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: #66c2ff;
        }

        .contenedor {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            padding: 40px;
        }

        .modulo {
            background-color: #39395c;
            padding: 30px;
            text-align: center;
            border-radius: 15px;
            transition: transform 0.2s;
            cursor: pointer;
        }

        .modulo:hover {
            transform: scale(1.05);
        }

        .modulo a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            display: block;
        }

        .logout {
            text-align: center;
            margin-top: 20px;
        }

        .logout a {
            color: #ff5555;
            text-decoration: none;
            font-weight: bold;
        }

        .logout a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>🛠 Panel del Administrador</header>

<div class="contenedor">
    <div class="modulo">
        <a href="productos.php">📦 Gestión de Productos</a>
    </div>
    <div class="modulo">
        <a href="pedidos.php">🧾 Gestión de Pedidos</a>
    </div>
    <div class="modulo">
        <a href="proveedores.php">👥 Proveedores</a>
    </div>
    <div class="modulo">
        <a href="reportes.php">📊 Reporte de Ventas</a>
    </div>
    <div class="modulo">
        <a href="pedidos_proveedor.php">🚚 Pedidos a Proveedores</a>
    </div>
    <div class="modulo">
        <a href="crear_pedido_proveedor.php">✍️ Crear Pedido a Proveedor</a>
    </div>
    <div class="modulo">
        <a href="asociar_producto_proveedor.php">🔧 Asociar Producto-Proveedor</a>
    </div>
    <div class="modulo">
        <a href="proveedores.php">📝 Agregar Nuevo Proveedor</a>
    </div>
</div>

<div class="logout">
    <a href="../logout.php">Cerrar sesión</a>
</div>

</body>
</html>
