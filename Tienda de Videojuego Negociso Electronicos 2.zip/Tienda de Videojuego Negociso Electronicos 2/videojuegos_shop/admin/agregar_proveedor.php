<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

$nombre = trim($_POST['nombre']);
$email = trim($_POST['contacto_email']);
$telefono = trim($_POST['telefono']);

if ($nombre && $email && $telefono) {
    $stmt = $conn->prepare("INSERT INTO proveedores (nombre, contacto_email, telefono) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nombre, $email, $telefono);
    $stmt->execute();
    $stmt->close();
}

header("Location: proveedores.php");
exit;
