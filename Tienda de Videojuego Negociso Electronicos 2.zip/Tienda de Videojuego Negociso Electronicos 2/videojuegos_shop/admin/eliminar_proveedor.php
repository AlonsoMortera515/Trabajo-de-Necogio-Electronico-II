<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

$id = intval($_GET['id']);
$conn->query("DELETE FROM proveedores WHERE id = $id");

header("Location: proveedores.php");
exit;
