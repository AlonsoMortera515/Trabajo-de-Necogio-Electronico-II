<?php
session_start();
include("../includes/db.php");

// Verificamos que sea admin
if (!isset($_SESSION["usuario_rol"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit();
}

// Cabeceras para forzar la descarga del CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=pedidos.csv');

// Abrimos la salida estándar para escribir el archivo
$output = fopen('php://output', 'w');

// Escribimos la fila de encabezados
fputcsv($output, ['ID Pedido', 'Cliente', 'Correo', 'Fecha', 'Estatus']);

// Consultamos los pedidos con datos de usuario
$sql = "SELECT p.id, p.fecha, p.estatus, u.nombre AS cliente_nombre, u.email AS cliente_email
        FROM pedidos p
        LEFT JOIN usuarios u ON p.usuario_id = u.id
        ORDER BY p.fecha DESC";

$resultado = $conn->query($sql);

// Verificamos y escribimos los datos
if ($resultado && $resultado->num_rows > 0) {
    while ($row = $resultado->fetch_assoc()) {
        fputcsv($output, [
            $row['id'],
            $row['cliente_nombre'],
            $row['cliente_email'],
            date("d/m/Y H:i", strtotime($row['fecha'])),
            ucfirst($row['estatus'])
        ]);
    }
} else {
    // Si no hay resultados, podemos poner un mensaje (opcional)
    fputcsv($output, ['No hay pedidos registrados']);
}

fclose($output);
exit;
?>
