<?php
session_start();
if ($_SESSION['correo'] !== 'pepe_mortera@htomail.com') {
    header("Location: ../login.php");
    exit();
}

include("../includes/db.php");
$resultado = $conn->query("SELECT * FROM prospectos ORDER BY fecha_registro DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Prospectos</title>
</head>
<body>
    <h2>Listado de Prospectos</h2>
    <table border="1">
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Mensaje</th>
            <th>Fecha</th>
        </tr>
        <?php while ($fila = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?php echo $fila['id']; ?></td>
                <td><?php echo $fila['nombre']; ?></td>
                <td><?php echo $fila['email']; ?></td>
                <td><?php echo $fila['mensaje']; ?></td>
                <td><?php echo $fila['fecha_registro']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
