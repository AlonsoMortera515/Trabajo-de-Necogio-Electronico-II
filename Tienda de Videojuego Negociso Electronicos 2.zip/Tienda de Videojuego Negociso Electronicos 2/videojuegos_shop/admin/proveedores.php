<?php
session_start();
include("../includes/db.php");

// Verifica si es administrador
if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Obtener proveedores existentes
$resultado = $conn->query("SELECT * FROM proveedores");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Proveedores</title>
    <style>
        body {
            background-color: #1e1e2f;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 30px;
        }

        h1, h2 {
            color: #66c2ff;
        }

        .contenedor {
            background-color: #2a2a40;
            padding: 20px;
            border-radius: 12px;
            max-width: 800px;
            margin: 0 auto 40px auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.4);
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: none;
            font-size: 16px;
        }

        button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #444;
            text-align: left;
        }

        th {
            background-color: #353552;
        }

        tr:nth-child(even) {
            background-color: #2e2e44;
        }

        a {
            color: #ff4d4d;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .volver {
            display: inline-block;
            margin-top: 20px;
            color: #66c2ff;
        }
    </style>
</head>
<body>

    <div class="contenedor">
        <h1>Gestión de Proveedores</h1>

        <h2>Agregar nuevo proveedor</h2>
        <form action="agregar_proveedor.php" method="POST">
            <label>Nombre del proveedor</label>
            <input type="text" name="nombre" required>

            <label>Correo electrónico</label>
            <input type="email" name="contacto_email" required>

            <label>Teléfono</label>
            <input type="text" name="telefono" required>

            <button type="submit">Agregar proveedor</button>
        </form>
    </div>

    <div class="contenedor">
        <h2>Lista de Proveedores</h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($prov = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($prov['nombre']) ?></td>
                        <td><?= htmlspecialchars($prov['contacto_email']) ?></td>
                        <td><?= htmlspecialchars($prov['telefono']) ?></td>
                        <td>
                            <a href="eliminar_proveedor.php?id=<?= $prov['id'] ?>" onclick="return confirm('¿Eliminar este proveedor?')">Eliminar</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <a class="volver" href="dashboard.php">← Volver al Dashboard</a>
    </div>

</body>
</html>
