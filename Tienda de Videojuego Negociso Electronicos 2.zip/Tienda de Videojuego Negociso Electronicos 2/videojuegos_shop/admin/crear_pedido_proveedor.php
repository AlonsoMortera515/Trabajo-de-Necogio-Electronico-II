<?php
session_start();
include("../includes/db.php");

// Solo admin
if (!isset($_SESSION["usuario_rol"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit();
}

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $proveedor_id = intval($_POST['proveedor_id']);
    $productos = $_POST['productos']; // Array de productos con 'producto_id' y 'cantidad'

    if ($proveedor_id && !empty($productos)) {
        // Insertar pedido
        $stmt = $conn->prepare("INSERT INTO pedidos_proveedor (proveedor_id, fecha, estatus) VALUES (?, NOW(), 'pendiente')");
        $stmt->bind_param("i", $proveedor_id);
        if ($stmt->execute()) {
            $pedido_id = $stmt->insert_id;
            $stmt->close();

            // Insertar detalles del pedido
            $insertDetalles = $conn->prepare("INSERT INTO detalle_pedido_proveedor (pedido_id, producto_id, cantidad) VALUES (?, ?, ?)");

            foreach ($productos as $prod) {
                $producto_id = intval($prod['producto_id']);
                $cantidad = intval($prod['cantidad']);
                if ($producto_id > 0 && $cantidad > 0) {
                    $insertDetalles->bind_param("iii", $pedido_id, $producto_id, $cantidad);
                    $insertDetalles->execute();
                }
            }
            $insertDetalles->close();

            $mensaje = "Pedido creado exitosamente.";
        } else {
            $mensaje = "Error al crear pedido.";
        }
    } else {
        $mensaje = "Debe seleccionar un proveedor y agregar al menos un producto con cantidad válida.";
    }
}

// Obtener proveedores
$proveedores = $conn->query("SELECT id, nombre FROM proveedores ORDER BY nombre ASC");

// Obtener productos para selector
$productos = $conn->query("SELECT id, nombre FROM productos ORDER BY nombre ASC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Crear Pedido a Proveedor</title>
    <style>
        body {
            background-color: #1e1e2f;
            color: white;
            font-family: Arial, sans-serif;
            margin: 40px;
        }
        h1 {
            color: #66c2ff;
            margin-bottom: 20px;
            text-align: center;
        }
        form {
            background: #39395c;
            padding: 20px;
            border-radius: 15px;
            max-width: 600px;
            margin: 0 auto;
            box-shadow: 0 0 15px rgba(102, 194, 255, 0.5);
        }
        label {
            display: block;
            margin: 15px 0 5px;
        }
        select, input[type="number"] {
            width: 100%;
            padding: 8px;
            border-radius: 7px;
            border: none;
            font-size: 16px;
        }
        button {
            margin-top: 20px;
            background: #2575fc;
            border: none;
            padding: 12px 20px;
            color: white;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
            font-size: 18px;
            transition: background 0.3s;
        }
        button:hover {
            background: #1a52c2;
        }
        .mensaje {
            text-align: center;
            margin-top: 20px;
            color: #f5a623;
            font-weight: bold;
        }
        .producto-fila {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
        }
        .producto-fila select {
            flex: 3;
        }
        .producto-fila input[type="number"] {
            flex: 1;
        }
        .agregar-producto {
            background: #5cb85c;
            border: none;
            padding: 8px 12px;
            border-radius: 7px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 15px;
            width: 100%;
            font-size: 16px;
            transition: background 0.3s;
        }
        .agregar-producto:hover {
            background: #449d44;
        }
    </style>
</head>
<body>

<h1>Crear Pedido a Proveedor</h1>

<form method="POST" id="form-pedido">
    <label for="proveedor_id">Proveedor:</label>
    <select name="proveedor_id" id="proveedor_id" required>
        <option value="">Seleccione un proveedor</option>
        <?php while ($prov = $proveedores->fetch_assoc()): ?>
            <option value="<?php echo $prov['id']; ?>"><?php echo htmlspecialchars($prov['nombre']); ?></option>
        <?php endwhile; ?>
    </select>

    <div id="productos-container">
        <div class="producto-fila">
            <select name="productos[0][producto_id]" required>
                <option value="">Seleccione un producto</option>
                <?php while ($prod = $productos->fetch_assoc()): ?>
                    <option value="<?php echo $prod['id']; ?>"><?php echo htmlspecialchars($prod['nombre']); ?></option>
                <?php endwhile; ?>
            </select>
            <input type="number" name="productos[0][cantidad]" min="1" placeholder="Cantidad" required>
        </div>
    </div>

    <button type="button" class="agregar-producto" id="agregar-producto-btn">+ Agregar otro producto</button>

    <button type="submit">Crear Pedido</button>

    <?php if ($mensaje): ?>
        <div class="mensaje"><?php echo $mensaje; ?></div>
    <?php endif; ?>
</form>

<a href="dashboard.php" class="btn-volver" style="display:block; margin: 20px auto; text-align:center; max-width: 600px; color:#66c2ff;">Volver al Dashboard</a>

<script>
    let contadorProductos = 1;

    document.getElementById('agregar-producto-btn').addEventListener('click', () => {
        const container = document.getElementById('productos-container');

        // Clonar la lista de productos para mantener opciones actualizadas
        const productosHTML = `<?php
            // Recargar productos para JS (necesario porque fetch_assoc avanzó el puntero)
            $productos->data_seek(0);
            $options = "";
            while ($prod = $productos->fetch_assoc()) {
                $options .= '<option value="'.$prod['id'].'">'.htmlspecialchars($prod['nombre']).'</option>';
            }
            echo addslashes($options);
        ?>`;

        const div = document.createElement('div');
        div.classList.add('producto-fila');
        div.innerHTML = `
            <select name="productos[${contadorProductos}][producto_id]" required>
                <option value="">Seleccione un producto</option>
                ${productosHTML}
            </select>
            <input type="number" name="productos[${contadorProductos}][cantidad]" min="1" placeholder="Cantidad" required>
        `;

        container.appendChild(div);
        contadorProductos++;
    });
</script>

</body>
</html>
