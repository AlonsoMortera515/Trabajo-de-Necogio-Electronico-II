<?php
session_start();
include("../includes/db.php");

// Solo admin
if (!isset($_SESSION["usuario_rol"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pedido_id'], $_POST['nuevo_estatus'])) {
    $pedido_id = intval($_POST['pedido_id']);
    $nuevo_estatus = $_POST['nuevo_estatus'];
    $estatus_validos = ['pendiente', 'en espera', 'entregado'];
    if (in_array($nuevo_estatus, $estatus_validos)) {
        $stmt = $conn->prepare("UPDATE pedidos_proveedor SET estatus = ? WHERE id = ?");
        $stmt->bind_param("si", $nuevo_estatus, $pedido_id);
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'msg' => 'Error en BD.']);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'msg' => 'Estatus inválido.']);
    }
    exit();
}

$sql = "SELECT pp.id, pp.fecha, pp.estatus, pr.nombre AS proveedor_nombre
        FROM pedidos_proveedor pp
        LEFT JOIN proveedores pr ON pp.proveedor_id = pr.id
        ORDER BY pp.fecha DESC";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Pedidos a Proveedores</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500&family=Roboto&display=swap');

    body {
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
        font-family: 'Roboto', sans-serif;
        color: #e0e6f8;
        margin: 40px;
        -webkit-font-smoothing: antialiased;
    }

    h1 {
        font-family: 'Orbitron', sans-serif;
        text-align: center;
        color: #42f5ef;
        font-size: 3rem;
        text-shadow: 0 0 10px #42f5ef, 0 0 30px #42f5ef;
        margin-bottom: 20px;
        letter-spacing: 3px;
    }

    .exportar {
        text-align: right;
        margin-bottom: 30px;
    }

    .exportar a {
        padding: 10px 25px;
        background: linear-gradient(90deg, #42f5ef, #00c6ff);
        color: #011;
        font-family: 'Orbitron', monospace;
        font-weight: 700;
        text-decoration: none;
        border-radius: 20px;
        box-shadow: 0 0 15px #42f5ef;
        transition: background 0.3s ease, box-shadow 0.3s ease;
    }

    .exportar a:hover {
        background: linear-gradient(90deg, #00c6ff, #42f5ef);
        box-shadow: 0 0 30px #00c6ff;
    }

    table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 15px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 0 40px rgba(66, 245, 239, 0.4);
    }

    thead tr {
        background: #0ff;
        color: #011;
        font-weight: 700;
        letter-spacing: 1.2px;
        font-size: 1.1rem;
    }

    th, td {
        padding: 18px 20px;
        text-align: left;
    }

    tbody tr {
        background: linear-gradient(90deg, #1e2a38, #223b51);
        box-shadow: 0 0 10px #0ff inset;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border-radius: 12px;
        cursor: default;
    }

    tbody tr:hover {
        transform: scale(1.03);
        box-shadow: 0 0 25px #42f5ef, 0 0 45px #42f5ef inset;
    }

    select.estatus-select {
        font-family: 'Orbitron', monospace;
        font-weight: 600;
        padding: 8px 14px;
        border-radius: 12px;
        border: none;
        cursor: pointer;
        color: #011;
        background: linear-gradient(45deg, #42f5ef, #00c6ff);
        box-shadow: 0 0 15px #42f5ef;
        transition: background 0.3s ease;
        text-transform: uppercase;
        letter-spacing: 1.2px;
    }

    select.estatus-select:hover {
        background: linear-gradient(45deg, #00c6ff, #42f5ef);
    }

    option.pendiente { color: #ff4d6d; font-weight: 700; }
    option.en-espera { color: #ffba3d; font-weight: 700; }
    option.entregado { color: #4caf50; font-weight: 700; }

    .btn-volver {
        margin-top: 40px;
        display: block;
        width: 220px;
        margin-left: auto;
        margin-right: auto;
        padding: 12px 0;
        text-align: center;
        font-family: 'Orbitron', monospace;
        font-weight: 700;
        background: linear-gradient(90deg, #42f5ef, #00c6ff);
        color: #011;
        border-radius: 20px;
        box-shadow: 0 0 25px #42f5ef;
        text-decoration: none;
        transition: background 0.3s ease, box-shadow 0.3s ease;
        letter-spacing: 1.5px;
    }

    .btn-volver:hover {
        background: linear-gradient(90deg, #00c6ff, #42f5ef);
        box-shadow: 0 0 40px #00c6ff;
    }
</style>
</head>
<body>

<h1>Pedidos a Proveedores</h1>

<div class="exportar">
    <a href="exportar_pedidos_proveedor.php">⬇️ Descargar CSV</a>
</div>

<table>
    <thead>
        <tr>
            <th>ID Pedido</th>
            <th>Proveedor</th>
            <th>Fecha</th>
            <th>Estatus</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($resultado && $resultado->num_rows > 0): ?>
            <?php while ($pedido = $resultado->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $pedido['id']; ?></td>
                    <td><?php echo htmlspecialchars($pedido['proveedor_nombre']); ?></td>
                    <td><?php echo date("d/m/Y H:i", strtotime($pedido['fecha'])); ?></td>
                    <td>
                        <select class="estatus-select" data-pedido-id="<?php echo $pedido['id']; ?>">
                            <option value="pendiente" <?php if($pedido['estatus'] == 'pendiente') echo 'selected'; ?> class="pendiente">Pendiente</option>
                            <option value="en espera" <?php if($pedido['estatus'] == 'en espera') echo 'selected'; ?> class="en-espera">En espera</option>
                            <option value="entregado" <?php if($pedido['estatus'] == 'entregado') echo 'selected'; ?> class="entregado">Entregado</option>
                        </select>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="4" style="text-align:center; padding: 30px;">No hay pedidos a proveedores.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<a href="dashboard.php" class="btn-volver">Volver al Dashboard</a>

<script>
    document.querySelectorAll('.estatus-select').forEach(select => {
        select.addEventListener('change', () => {
            const pedidoId = select.getAttribute('data-pedido-id');
            const nuevoEstatus = select.value;
            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `pedido_id=${pedidoId}&nuevo_estatus=${encodeURIComponent(nuevoEstatus)}`
            })
            .then(res => res.json())
            .then(data => {
                if(!data.success) {
                    alert('Error al actualizar estatus: ' + (data.msg || 'Desconocido'));
                    select.value = select.getAttribute('data-current-estatus');
                } else {
                    select.setAttribute('data-current-estatus', nuevoEstatus);
                }
            })
            .catch(() => {
                alert('Error de comunicación con servidor.');
                select.value = select.getAttribute('data-current-estatus');
            });
        });
        select.setAttribute('data-current-estatus', select.value);
    });
</script>

</body>
</html>
