<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Calcular datos
$sql = "
    SELECT 
        COUNT(*) AS total_pedidos,
        SUM(dp.cantidad * dp.precio_unitario) AS total_ventas
    FROM pedidos p
    JOIN detalle_pedido dp ON dp.pedido_id = p.id
";
$resultado = $conn->query($sql);
$data = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Ventas</title>
    <style>
        body {
            background-color: #1e1e2f;
            color: white;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .card {
            background-color: #2f2f44;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
        }

        .card h2 {
            margin: 0;
            color: #66c2ff;
        }

        .back {
            margin-top: 20px;
        }

        a {
            color: #66c2ff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>📊 Reporte de Ventas</h1>

    <div class="card">
        <h2>Total de Pedidos: <?= $data['total_pedidos'] ?? 0 ?></h2>
        <h2>Total Vendido: <?= number_format($data['total_ventas'] ?? 0, 2) ?> MXN</h2>
    </div>

    <div class="back">
        <a href="dashboard.php">← Volver al Dashboard</a>
    </div>
</body>
</html>
