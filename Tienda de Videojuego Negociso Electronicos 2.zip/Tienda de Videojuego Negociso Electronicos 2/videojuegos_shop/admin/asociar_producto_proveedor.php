<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Obtener productos y proveedores
$productos = $conn->query("SELECT id, nombre FROM productos");
$proveedores = $conn->query("SELECT id, nombre FROM proveedores");

// Procesar asociación
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $producto_id = $_POST["producto_id"];
    $proveedor_id = $_POST["proveedor_id"];

    $stmt = $conn->prepare("INSERT INTO producto_proveedor (producto_id, proveedor_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $producto_id, $proveedor_id);
    $stmt->execute();
    $stmt->close();
    
    header("Location: asociar_producto_proveedor.php");
    exit;
}

// Obtener asociaciones actuales
$asociaciones = $conn->query("
    SELECT pp.id, p.nombre AS producto, pr.nombre AS proveedor
    FROM producto_proveedor pp
    JOIN productos p ON pp.producto_id = p.id
    JOIN proveedores pr ON pp.proveedor_id = pr.id
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Asociar Productos con Proveedores</title>
    <style>
        body {
            background-color: #1e1e2f;
            color: white;
            font-family: Arial, sans-serif;
            padding: 30px;
        }

        .contenedor {
            background-color: #2a2a40;
            padding: 20px;
            border-radius: 12px;
            max-width: 800px;
            margin: 0 auto 30px auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.4);
        }

        h1, h2 {
            color: #66c2ff;
        }

        select, button {
            padding: 10px;
            font-size: 16px;
            border-radius: 6px;
            border: none;
            margin-bottom: 15px;
            width: 100%;
        }

        button {
            background-color: #28a745;
            color: white;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #444;
        }

        th {
            background-color: #353552;
        }

        tr:nth-child(even) {
            background-color: #2e2e44;
        }

        .volver {
            display: inline-block;
            margin-top: 20px;
            color: #66c2ff;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="contenedor">
    <h1>Asociar Producto con Proveedor</h1>

    <form method="POST">
        <label>Selecciona un producto:</label>
        <select name="producto_id" required>
            <option value="">-- Selecciona --</option>
            <?php while ($prod = $productos->fetch_assoc()): ?>
                <option value="<?= $prod['id'] ?>"><?= htmlspecialchars($prod['nombre']) ?></option>
            <?php endwhile; ?>
        </select>

        <label>Selecciona un proveedor:</label>
        <select name="proveedor_id" required>
            <option value="">-- Selecciona --</option>
            <?php while ($prov = $proveedores->fetch_assoc()): ?>
                <option value="<?= $prov['id'] ?>"><?= htmlspecialchars($prov['nombre']) ?></option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Asociar</button>
    </form>
</div>

<div class="contenedor">
    <h2>Asociaciones existentes</h2>
    <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th>Proveedor</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($asoc = $asociaciones->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($asoc['producto']) ?></td>
                    <td><?= htmlspecialchars($asoc['proveedor']) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a class="volver" href="dashboard.php">← Volver al Dashboard</a>
</div>

</body>
</html>
