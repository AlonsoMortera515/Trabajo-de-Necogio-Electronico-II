<?php
session_start();
include("../includes/db.php");

// Verificar si es admin
if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "ID de pedido no especificado.";
    exit;
}

$pedido_id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT dp.producto_id, pr.nombre, dp.cantidad, dp.precio_unitario 
                        FROM detalle_pedido dp 
                        JOIN productos pr ON dp.producto_id = pr.id 
                        WHERE dp.pedido_id = ?");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Detalle Pedido #<?php echo $pedido_id; ?></title>
    <style>
        body {
            background-color: #1e1e2f;
            color: white;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #444;
            text-align: left;
        }
        th {
            background-color: #2f2f44;
        }
    </style>
</head>
<body>
    <h1>Detalle del Pedido #<?php echo $pedido_id; ?></h1>
    <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()):
                $subtotal = $row['cantidad'] * $row['precio_unitario'];
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($row['cantidad']); ?></td>
                    <td><?php echo htmlspecialchars($row['precio_unitario']); ?></td>
                    <td><?php echo $subtotal; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <p><a href="pedidos.php">Volver a Pedidos</a></p>
</body>
</html>
