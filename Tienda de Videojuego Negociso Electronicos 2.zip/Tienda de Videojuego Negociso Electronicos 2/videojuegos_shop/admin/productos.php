<?php
session_start();
include("../includes/db.php");

// Verifica si el usuario es admin
if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_rol"] != "admin") {
    header("Location: ../login.php");
    exit;
}

// Agregar producto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["nombre"])) {
    $nombre = $_POST["nombre"];
    $descripcion = $_POST["descripcion"];
    $precio = $_POST["precio"];

    $sql = "INSERT INTO productos (nombre, descripcion, precio) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssd", $nombre, $descripcion, $precio);
    $stmt->execute();
    $stmt->close();

    header("Location: productos.php?agregado=1");
    exit;
}

// Eliminar producto
if (isset($_GET["eliminar"])) {
    $id = $_GET["eliminar"];
    $conn->query("DELETE FROM productos WHERE id = $id");
    header("Location: productos.php?eliminado=1");
    exit;
}

// Obtener todos los productos
$resultado = $conn->query("SELECT * FROM productos");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Administrar Productos</title>
    <style>
        body {
            background-color: #1e1e2f;
            font-family: Arial, sans-serif;
            color: white;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #66c2ff;
        }

        form, table {
            width: 80%;
            margin: 20px auto;
            background-color: #2f2f44;
            padding: 20px;
            border-radius: 10px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: none;
        }

        .btn {
            background-color: #4caf50;
            padding: 10px;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-danger {
            background-color: #e53935;
        }

        table th, table td {
            padding: 12px;
            text-align: center;
        }

        table th {
            background-color: #39395c;
        }

        a {
            color: #66c2ff;
            text-decoration: none;
        }
    </style>
</head>
<body>

<h2>Administración de Productos</h2>

<?php if (isset($_GET["agregado"])): ?>
    <p style="text-align:center; color: #4caf50;">Producto agregado correctamente.</p>
<?php endif; ?>

<?php if (isset($_GET["eliminado"])): ?>
    <p style="text-align:center; color: #e53935;">Producto eliminado.</p>
<?php endif; ?>

<!-- Formulario para agregar producto -->
<form method="POST">
    <h3>Nuevo Producto</h3>
    <input type="text" name="nombre" placeholder="Nombre del producto" required>
    <textarea name="descripcion" placeholder="Descripción" required></textarea>
    <input type="number" name="precio" placeholder="Precio" step="0.01" required>
    <button type="submit" class="btn">Agregar producto</button>
</form>

<!-- Tabla de productos existentes -->
<table>
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Precio</th>
        <th>Acciones</th>
    </tr>

    <?php while ($producto = $resultado->fetch_assoc()): ?>
        <tr>
            <td><?php echo $producto["id"]; ?></td>
            <td><?php echo $producto["nombre"]; ?></td>
            <td>$<?php echo number_format($producto["precio"], 2); ?></td>
            <td>
                <a class="btn btn-danger" href="productos.php?eliminar=<?php echo $producto["id"]; ?>">Eliminar</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
